
from tkinter import*
from turtle import width

from PIL import Image, ImageTk
from numpy import var
import string
import random
from tkinter import messagebox


class Labelwindow:
    def __init__(self):
        self.root=Tk()  # create GUI
        self.root.title (" password genertor  ")
        self.root.config(bg="white")
        self.root.geometry('500x600+400+100')
        self. root.resizable(height = False, width = False)
        self.lowercase_alphabet=string.ascii_lowercase
        self.uppercase_letters=string.ascii_uppercase
        self.number='1234567890'
        self.symbol='@#$&*/'
        self.var=IntVar()
        self.var.set(8)
    
   
           

        # Show image using label
        self.image = ImageTk.PhotoImage(Image.open('p2.png').resize((50, 50)))
        self.label1 = Label(self.root, image = self.image,fg="white",bg="white",width=50,height=50)
    
        self.label1.place(x=20,y=5)
        self.label2 = Label(self.root,text="PASSWORD GENERATOR",fg="black",bg="white",font=("helvetica", 20,"bold"))
    
        self.label2.place(x=80,y=10)
   
        self.state_1=StringVar()
        self.state_1.set(FALSE)
        self.state_2=StringVar()
        
        self.state_2.set(FALSE)
        self.state_3=StringVar()
        
        self.state_3.set(FALSE)
        self.state_4=StringVar()
        
        self.state_4.set(FALSE)
        
        
        
       
        self.label3 = Label(self.root,text="",fg="black",bg="blue",width=70,font=("helvetica", 10,"bold"))
        self.label3.place(x=0,y=55)
        self.label3 = Label(self.root,text="Total number of characters in the password ",fg="black",bg="white",width=33,font=("helvetica", 19))
        self.label3.place(x=0,y=80)
        self.spin=Spinbox(self.root,width=25,from_=0,to=20,textvariable=var)
        self.spin.place(x=15,y=120)
        self.entry_1=Label(self.root,text="",bg="black",border=2,width=22,highlightbackground="black",fg="white",font=("helvetica", 22,"bold"))
        self.entry_1.place(x=3,y=180)
        
        self.label3 = Label(self.root,text="ABC upper letters",fg="black",bg="white",font=("helvetica", 10,"bold"))
        self.label3.place(x=100,y=250)
        self.label3 = Label(self.root,text="abc lower letters",fg="black",bg="white",font=("helvetica", 10,"bold"))
        self.label3.place(x=100,y=300)
        self.label3 = Label(self.root,text="123 numbers",fg="black",bg="white",font=("helvetica", 10,"bold"))
        self.label3.place(x=100,y=350)
        self.label3 = Label(self.root,text="symbol @#$",fg="black",bg="white",font=("helvetica", 10,"bold"))
        self.label3.place(x=100,y=400)
        
        self.C1 = Checkbutton( var = self.state_1,onvalue = self.uppercase_letters, offvalue = OFF,bg="white")
        self.C1.place(x=50,y=250)
        self.C2 = Checkbutton( var = self.state_2,onvalue = self.lowercase_alphabet, offvalue = OFF,bg="white")
        self.C2.place(x=50,y=300)
        self.C3 = Checkbutton( var = self.state_3,onvalue = self.number, offvalue = OFF,bg="white")
        self.C3.place(x=50,y=350)
        self.C3 = Checkbutton( var = self.state_4,onvalue = self.symbol, offvalue = OFF,bg="white")
        self.C3.place(x=50,y=400)
        
        
        

        
        
        
        #Button
        Button(self.root,text="copy",bg="orange",fg="black",width=8,font="italic 15",border=2).place(x=402,y=179)
        
        Button(self.root,text="Generate",bg="orange",fg="black",width=8,font="italic 15",border=4,command=self.generate_password).place(x=100,y=500)
        self.root.mainloop()
    def generate_password(self):

        self.lowercase_alphabet = string.ascii_lowercase
        self.uppercase_letters = string.ascii_uppercase
        self.number = '123456789'
        self.symbols = "{}[]()*;/,_-"
        global  combine
        if self.state_1.get()==self.uppercase_letters:

            combine = self.uppercase_letters
        else:
            pass
        if self.state_2.get()==self.lowercase_alphabet:
              combine  +=self.lowercase_alphabet
        else:
            pass
        if self.state_3==self.number:
            combine += self.number
        else:
            pass
        if self.state_4==self.symbol:
            combine +=self.symbol
        else:
            pass
        
        self.length = int(self.spin.get())
        
        self.password = "".join(random.sample(combine, self.length))
        self.entry_1['text'] = self.password
 
        #Function to copy the password

    def copy_password(self):
        self.info=self.password

        self.clipboard_clear()

        self.clipboard_append(self.info) 
        self.messagebox.showinfo("Success", "The password has been copied successfully")

        print(self.password)

        self.generate_password()

        
if __name__=="__main__":
    obj= Labelwindow()
    